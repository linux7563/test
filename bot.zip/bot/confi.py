api_id = 29011362
api_hash = "c6a70248df5723c5150563de3b1f122c" 
apihash_accounts = "2550e8e2ab083b69e9b744e155af0fff"
apiid_accounts = 21101670
token = "6097471200:AAEELfniSD1sR_vdOzSUups36ZwEdoqGpZA" 
owner = 1487353688
twofanew = "Abolfazl5465"



